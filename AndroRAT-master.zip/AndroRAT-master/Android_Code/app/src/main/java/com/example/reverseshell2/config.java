package com.example.reverseshell2;

public class config {
    public static String IP = "192.168.0.105";
    public static String port = "8888";
    public static boolean icon = true;
}